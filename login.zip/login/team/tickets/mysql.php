
    <?php
    $host = "localhost";
    $name = "tickets";
    $user = "tickets";
    $passwort = "jvT77Mt8gsaGFDf8";
    try{
        $mysql = new PDO("mysql:host=$host;dbname=$name", $user, $passwort);
    } catch (PDOException $e){

    }
    ?>
    